-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 21, 2016 at 11:39 AM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a3176676_jsos`
--

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `description` text,
  `photo_count` int(4) DEFAULT NULL,
  `cover` varchar(20) DEFAULT NULL,
  `album_folder` varchar(20) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` VALUES(1, 'Leadership Training', 'leadership training desc leadership training desc leadership training desc \r\n	leadership training desc leadership training desc leadership training desc \r\n	leadership training desc leadership training desc leadership training desc \r\n	leadership training desc leadership training desc leadership training desc', 17, '12.jpg', '1', '0000-00-00 00:00:00', '2014-07-29 14:43:17');
INSERT INTO `albums` VALUES(2, 'Ministry Mart', 'Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc \r\n	Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc \r\n	Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc \r\n	Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc Ministry Mart Desc ', 26, '14.jpg', '2', '0000-00-00 00:00:00', '2014-07-29 14:43:17');
INSERT INTO `albums` VALUES(3, 'Prayer Fellowship', 'Prayer Fellowship desc Prayer Fellowship desc Prayer Fellowship desc \r\n	Prayer Fellowship desc Prayer Fellowship desc Prayer Fellowship desc \r\n	Prayer Fellowship desc Prayer Fellowship desc Prayer Fellowship desc \r\n	Prayer Fellowship desc Prayer Fellowship desc Prayer Fellowship desc ', 23, '14.jpg', '3', '0000-00-00 00:00:00', '2014-07-29 14:43:17');
INSERT INTO `albums` VALUES(4, 'Morning Careflock', 'Morning Careflock desc Morning Careflock desc Morning Careflock desc \r\n	Morning Careflock desc Morning Careflock desc Morning Careflock desc \r\n	Morning Careflock desc Morning Careflock desc Morning Careflock desc \r\n	Morning Careflock desc Morning Careflock desc Morning Careflock desc ', 109, '3.jpg', '4', '0000-00-00 00:00:00', '2014-07-29 14:43:17');
INSERT INTO `albums` VALUES(5, 'Worship Commitment', 'Worship commitment desc Worship commitment desc Worship commitment desc \r\n	Worship commitment desc Worship commitment desc Worship commitment desc \r\n	Worship commitment desc Worship commitment desc Worship commitment desc \r\n	Worship commitment desc Worship commitment desc Worship commitment desc ', 80, '52.jpg', '5', '0000-00-00 00:00:00', '2014-07-29 14:43:17');

-- --------------------------------------------------------

--
-- Table structure for table `historical_glimpse`
--

CREATE TABLE `historical_glimpse` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `week` date DEFAULT NULL,
  `header_title` varchar(100) DEFAULT NULL,
  `day_in_int` varchar(3) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(30) DEFAULT 'Jose Tacadena',
  `img_content` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `historical_glimpse`
--

INSERT INTO `historical_glimpse` VALUES(1, NULL, 'June', '5', NULL, 'Jose Tacadena', '06-05.jpg');
INSERT INTO `historical_glimpse` VALUES(2, NULL, 'June', '6', NULL, 'Jose Tacadena', '06-06.jpg');
INSERT INTO `historical_glimpse` VALUES(3, NULL, 'June', '14', NULL, 'Jose Tacadena', '06-14.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pastorsblog`
--

CREATE TABLE `pastorsblog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `week` date DEFAULT NULL,
  `header_title` varchar(100) DEFAULT NULL,
  `series` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(30) DEFAULT 'Jose Tacadena',
  `content` text,
  `img1` varchar(20) DEFAULT NULL,
  `img2` varchar(20) DEFAULT NULL,
  `img3` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pastorsblog`
--

INSERT INTO `pastorsblog` VALUES(1, '1999-02-01', 'FEBRUARY 1998', 'Miscellaneous Weekly Magazine', 'Crying for "PAPA"', 'Jose Tacadena', '\r\n    <p class=''bottom-10''>After two years, when the late night nursing were starting to exhaust my loving wife Del, I knew it was time for me to take over.  At least, for the meantime.</p>\r\n    <p class=''bottom-10''>Jhesed, our youngest kid, was then still accustomed to waking up five to six times from night to dawn.  His craving for a newly prepared milk and the occasional call to pee were the culprits.</p>\r\n    <p class=''bottom-10''>But I am a mega-sleeper, particularly after a hard day’s work.  You guessed it.  I did not look forward to being awakened randomly and many times during the wee hours of the day.</p>\r\n    <p class=''bottom-10''>"I don’t know how you do it", I’d often said to Del. After all, she works harder than me and has more daily pressures but is more energetic to care for our kids.</p>\r\n    <p class=''bottom-10''>I confess I balked at the unholy hours feeding party because Jhesed always awoke crying, "Mama, dede!" Of course, I’m not competing with my wife.  But I admit I feel like a second fiddle mom, And not a very good one at that.</p>\r\n    <p class=''bottom-10''>In fact, I even started out more as a hindrance than a help. Jhesed’s cries were not enough to wake em up although only my wife separates him from me on our family –sized bed.</p>\r\n    <p class=''bottom-10''>I eventually decided to sleep just beside our child, and prayed that I become more sensitive to him.  I also requested my wife to nudge me with here elbow whenever I failed to respond immediately our third child’s call.</p>\r\n    <p class=''bottom-10''>The elbow and relentless cries for "mama" were not pleasant motivators, with the first whimper, I begun rationalizing, and then murmuring.</p>\r\n    <p class=''bottom-10''>"Why does Jhesed have to continue sucking milk when he is already past two years old? Why do I have to volunteer doing this when Del could do it best?"</p>\r\n    <p class=''bottom-10''>But still, the cry for "Mama" went on, Yawning, I sat up on bed and groped for the milk some two arms length away. I took a deep breath and announced hopefully, "papa is here, Just wait a minute."</p>\r\n    <p class=''bottom-10''>To my pleasant surprise, Jhesed fell silent.</p>\r\n    <p class=''bottom-10''>"Well, that wasn’t so hard," I thought and continued preparing his milk.</p>\r\n    <p class=''bottom-10''>"Mamaaa!" the cry blasted forth with renewed vigor.</p>\r\n    <p class=''bottom-10''>Startled, I stopped, then sighed. I tapped his shoulder with my left and whispered, "Jhesed, just wait."</p>\r\n\r\n    <p class=''bottom-10''>Excitement pricked me, when as a response; my third child opened his eyes to look at me. Though the light was turned off, the full moon and the rays of the Meralco post lamp outside were clearly illuminating our second floor master’s bedroom.  Our eyes met.  Suspense grew inside me when Jhesed gave an impish smile.</p>\r\n    <p class=''bottom-10''>But just as suddenly, he cried out again, Mammmmaaaaa! Dedee! shattering my eardrums as well as my ego.  I gave him his milk and this quieted him.</p>\r\n    <p class=''bottom-10''>Day after day, bottle after bottle, I pushed on through the cries for "Mama" – dutifully, if not lovingly, Soon however, I began to be sensitive to his cries. </p>\r\n    <p class=''bottom-10''>I also begun to enjoy serving him, before long, I was even anticipating for that slight, uneasy move or simplest whimper to feed him early on, complete with a father’s touch.</p>\r\n    <p class=''bottom-10''>On sentimental nights, I would embraced him and whisper to him some reassuring words, That his dad loves him-while he’s already contented with his milk, All these amidst the soft cries and pants for "Mama!".</p>\r\n    <p class=''bottom-10''>And then late one night, it happened.</p>\r\n    <p class=''bottom-10''>Lost in heavy sleep, I stirred as a strange sound tapped lightly on my ear.  It wasn’t a cry, but more of a whisper.</p>\r\n    <p class=''bottom-10''>"Pa-pa.."\r\n    <p class=''bottom-10''>My eyes flickered open, closed again. Shifting to my left, my head tilted back to get a good glimpse of my child.</p>\r\n    <p class=''bottom-10''>"Pa-paaa! Pa-paaa!"\r\n    <p class=''bottom-10''>Bold and full throated, the small voice pier red the dark mornings like the horns of a triumphant politician.</p>\r\n    <p class=''bottom-10''>My eyes exploded open.  I was even more surprised to see my child gazing at me and smiling.</p>\r\n    <p class=''bottom-10''>"Papa!" he whispered, "Papa, Dede"\r\n    <p class=''bottom-10''>Half lurching from bed , I scoped Jhesed in my arms. "That’s my son" I blurted out, "Yes that’s my son"</p>\r\n    <p class=''bottom-10''>"What’s going on?" Del mumbled sleepishly. "What’s the noise all about?" </p>\r\n    <p class=''bottom-10''>Sleepishly, I lowered Jhesed back on his place, My child appeared already awake at that time, but was not a bit uneasy. Concealing my excitement, I retorted to Del, "Nothing, I was just talking to Jhesed."</p>\r\n\r\n    <p class=''bottom-10''>I begun to prepare his milk , I don’t know how many time I had been doing that, but this time, it was different,.  Especially with Jhesed anticipating on his father’s service.</p>\r\n    <p class=''bottom-10''>After receiving the bottle of milk, my child moved closer to me.  He extended his left arm to my cheeks as if to appreciate what I’ve done.  I tell you – it felt so good, real good.</p>\r\n    <p class=''bottom-10''>Indeed, my should was impressed that night when I first heard my son call me "Papa"</p>\r\n    <p class=''bottom-10''>Certainly, my joy came partly from waiting so long for him to acknowledge the bond between us, And yet when I had rejoiced fully and both he and Del were asleep again, I lay in bed staring at the stars visible from my views.  I was gripped by something deeper.</p>\r\n    <p class=''bottom-10''>I was identifying with the cry of my son, In his baby’s voice, I heard something I recognized in myself; I believe every man pants for that cry from the depths of his soul.  It is the most basic cry for security, safety and love amidst a dark and lonely world, ‘Save me, Father God!’</p>\r\n    <p class=''bottom-10''>I remember someone wrote, "Nothing will help you understand the love of God like having a child of your own". I think he was right.</p>\r\n    <p class=''bottom-10''>May we fathers and mothers dare to listen to the cry for "Papa" in our own hearts so we can recognized it in our own kids and respond in love.</p>\r\n    <p class=''bottom-10''>May everyone else hearten to his innate human cry for the Supreme Father in our lives, so that we can have greater peace, love and power that what we used to have as self-reliant. Self-made people</p>\r\n\r\n    <p class=''bottom-10''>This is how we can fully understand God, who for His love for us has given us His every life, so that we will no longer be alienated to Him.</p>\r\n    <p class=''bottom-10''>By believing in His Son Jesus, we can be empowered to be God’s children, whereby we cry to Him, "Abba (Daddy), Father!")</p>\r\n    <p class=''bottom-10''>(I John 4:10, John 1:12, Romans 5:8)</p>\r\n\r\n\r\n    ', '1999-02-01a.jpg', NULL, NULL);
INSERT INTO `pastorsblog` VALUES(2, '1997-11-25', 'November 1997', 'Mr & Ms', 'Uncovering Myths about Love', 'Jose Tacadena', '\r\n    <p class=''bottom-20''>You’ve been feeling fine, but suddenly you’re hot, almost feverish. You can’t seem to get a hold to your breath. Your mouth feels it’s full of cotton. You try to speak but no sound comes out. You then try to move, but your limber muscles seem paralyzed.</p>\r\n\r\n    <p class=''bottom-20''>Should someone call an ambulance? Are you about to have a heart attack at the peak of your youth?</p>\r\n    <p class=''bottom-10''>No. It’s just that a special somebody you’ve hoping to get to know a lot better just walked into the room. You are in the initial stage of Localized Onset of Varied Emotions, more commonly known as LOVE.</p>\r\n    <p class=''bottom-10''>There’s no need to see a doctor. He can’t help you. But it is time for intense scrutiny – some self-diagnosis. Although the symptoms of love are easy to identify, love itself is always misdefined. If that happens, you may fall for a fake—make—believe masquerading as the real thing.</p>\r\n    <p class=''bottom-10''>How can you tell the difference? One important protection is to understand the myths that surround the true meaning of love.</p>\r\n\r\n    <p class=''bottom-20''><b>Myth # 1: I know its love because of the way I feel</b></p>\r\n\r\n    <p class=''bottom-10''>It is easy grow up believing love is just a feeling. After all, there are some very real feelings that accompany love – excitement, anticipation, surprise. However, if you measure love relationship by the feelings you experience, you’ve in for the biggest roller coaster ride of your life. Feelings are unpredictable. They give way quickly and can’t be a sure foundation, especially of a relationship.</p>\r\n    <p class=''bottom-10''>Instead, it is important that your feelings be accompanied by actions of patience, kindness, courtesy, commitment, responsibility, honestly, integrity and purity. These are the foundation needed to build a relationship on.</p>\r\n\r\n    <p class=''bottom-20''><b> Myth # 2: I know it’s love if it makes me happy</b></p>\r\n        \r\n    <p class=''bottom-10''>This is related to the first one because happiness is a feeling. Yet, there is more involved here than a feeling. Whose happiness are we talking about? Your happiness.</p>\r\n    <p class=''bottom-10''>Describing love this way put you in the center and requires every activity, every emotion and every person add to your happiness. Although some people respect to find love with this formula, all that ever exist is self-centeredness. Self-centeredness eventually leads to isolation not love.</p>\r\n\r\n    <p class=''bottom-20''><b>Myth # 3: I know its love because of physical attraction</b></p>\r\n        \r\n    <p class=''bottom-10''>Of course, there will be mysterious magnetic field pulling two people together when they are uncovering a love relationship. And there will be a chemistry that defies any formula. But there’s more to love than physics and chemistry.</p>\r\n    <p class=''bottom-10''>The Bible tells us that our bodies are “fearfully and wonderfully made” (Psalms 139:14). This becomes unavoidably true in the area of physical reaction to the opposite sex.</p>\r\n    <p class=''bottom-10''>When you are with that special someone, the brain begins sending chemically coded messages to other parts of the body.  These signals result in physical reactions, fast heartbeat, sudden perspiration, even a feeling of euphoria. The only problem is that these signals only register physical attraction, not commitment and care for each other.  While physical attraction is an essential ingrediaent in romantic love, it alone is not an indicator of true love.</p>\r\n\r\n    <p class=''bottom-20''><b>MYTH # 4: I know it’s love when nothing else matters</b></p>\r\n\r\n    <p class=''bottom-10''>Someone embracing this myth is saying, “As long as we’re in love we don’t have to worry about anything else.” When the intensity of physical attraction is the only way you identify real love, then, other important factors lurk in the shadows.  The problem is that as you focus on intense feelings of attraction, differences such as age, maturity, spiritual commitment, and compatibility don’t seem to matter, After all, being analytical isn’t very romantic.\r\n    <p class=''bottom-10''>But real love looks at the difference.  Real love does ask the tough questions.  It listens to more than the answers of a heart in the middle of romantic feeling.</p>\r\n    <p class=''bottom-10''>Another part of this myth surfaces in the area of neglected responsibilities.  When two people in love focus on each other in a way that neglects everyone and everything else.  What they call love is just a form of escapism.  Real love, on the other hand, enjoys a relationship in the context of keeping commitments and respecting the rights of family and friends</p>\r\n\r\n    <p class=''bottom-20''><b>MYTH # 5: I know its love when I don’t care what others think</b></p>\r\n\r\n    <p class=''bottom-10''>Many accept this myth as truth.  If a relationship goes against the good counsel of family and friends, the reaction is, “Who cares as long as we’ve got each other?”</p>\r\n    <p class=''bottom-10''>On the surface, this may appear romantic and courageous; however, it is really another form of self-centeredness.  Instead of announcing love’s inner stance in your life, you stubbornly proclaim that your perspective is the only one that counts.</p>\r\n    <p class=''bottom-10''>Don’t be fooled by these myths.  Unmask them by confronting the real definition of love that endures.  St John the Apostle reminds us that God is love (I John 4:6)</p>\r\n    <p class=''bottom-10''>Anything that lacks God’s honesty, integrity and purity is a counterfeit.</p>\r\n    <p class=''bottom-10''>Why settle for anything less than real love at its best</p>\r\n    ', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `album_id` int(20) DEFAULT NULL,
  `album_folder` int(20) DEFAULT NULL,
  `album_title` varchar(64) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `caption` text,
  `photo` varchar(20) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=256 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` VALUES(1, 1, 1, 'Leadership Training', NULL, NULL, '1.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(2, 1, 1, 'Leadership Training', NULL, NULL, '2.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(3, 1, 1, 'Leadership Training', NULL, NULL, '3.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(4, 1, 1, 'Leadership Training', NULL, NULL, '4.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(5, 1, 1, 'Leadership Training', NULL, NULL, '5.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(6, 1, 1, 'Leadership Training', NULL, NULL, '6.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(7, 1, 1, 'Leadership Training', NULL, NULL, '7.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(8, 1, 1, 'Leadership Training', NULL, NULL, '8.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(9, 1, 1, 'Leadership Training', NULL, NULL, '9.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(10, 1, 1, 'Leadership Training', NULL, NULL, '10.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(11, 1, 1, 'Leadership Training', NULL, NULL, '11.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(12, 1, 1, 'Leadership Training', NULL, NULL, '12.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(13, 1, 1, 'Leadership Training', NULL, NULL, '13.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(14, 1, 1, 'Leadership Training', NULL, NULL, '14.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(15, 1, 1, 'Leadership Training', NULL, NULL, '15.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(16, 1, 1, 'Leadership Training', NULL, NULL, '16.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(17, 1, 1, 'Leadership Training', NULL, NULL, '17.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(18, 2, 2, 'Ministry Mart', NULL, NULL, '1.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(19, 2, 2, 'Ministry Mart', NULL, NULL, '2.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(20, 2, 2, 'Ministry Mart', NULL, NULL, '3.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(21, 2, 2, 'Ministry Mart', NULL, NULL, '4.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(22, 2, 2, 'Ministry Mart', NULL, NULL, '5.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(23, 2, 2, 'Ministry Mart', NULL, NULL, '6.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(24, 2, 2, 'Ministry Mart', NULL, NULL, '7.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(25, 2, 2, 'Ministry Mart', NULL, NULL, '8.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(26, 2, 2, 'Ministry Mart', NULL, NULL, '9.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(27, 2, 2, 'Ministry Mart', NULL, NULL, '10.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(28, 2, 2, 'Ministry Mart', NULL, NULL, '11.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(29, 2, 2, 'Ministry Mart', NULL, NULL, '12.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(30, 2, 2, 'Ministry Mart', NULL, NULL, '13.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(31, 2, 2, 'Ministry Mart', NULL, NULL, '14.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(32, 2, 2, 'Ministry Mart', NULL, NULL, '15.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(33, 2, 2, 'Ministry Mart', NULL, NULL, '16.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(34, 2, 2, 'Ministry Mart', NULL, NULL, '17.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(35, 2, 2, 'Ministry Mart', NULL, NULL, '18.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(36, 2, 2, 'Ministry Mart', NULL, NULL, '19.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(37, 2, 2, 'Ministry Mart', NULL, NULL, '20.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(38, 2, 2, 'Ministry Mart', NULL, NULL, '21.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(39, 2, 2, 'Ministry Mart', NULL, NULL, '22.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(40, 2, 2, 'Ministry Mart', NULL, NULL, '23.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(41, 2, 2, 'Ministry Mart', NULL, NULL, '24.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(42, 2, 2, 'Ministry Mart', NULL, NULL, '25.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(43, 2, 2, 'Ministry Mart', NULL, NULL, '26.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(44, 3, 3, 'Prayer Fellowship', NULL, NULL, '1.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(45, 3, 3, 'Prayer Fellowship', NULL, NULL, '2.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(46, 3, 3, 'Prayer Fellowship', NULL, NULL, '3.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(47, 3, 3, 'Prayer Fellowship', NULL, NULL, '4.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(48, 3, 3, 'Prayer Fellowship', NULL, NULL, '5.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(49, 3, 3, 'Prayer Fellowship', NULL, NULL, '6.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(50, 3, 3, 'Prayer Fellowship', NULL, NULL, '7.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(51, 3, 3, 'Prayer Fellowship', NULL, NULL, '8.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(52, 3, 3, 'Prayer Fellowship', NULL, NULL, '9.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(53, 3, 3, 'Prayer Fellowship', NULL, NULL, '10.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(54, 3, 3, 'Prayer Fellowship', NULL, NULL, '11.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(55, 3, 3, 'Prayer Fellowship', NULL, NULL, '12.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(56, 3, 3, 'Prayer Fellowship', NULL, NULL, '13.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(57, 3, 3, 'Prayer Fellowship', NULL, NULL, '14.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(58, 3, 3, 'Prayer Fellowship', NULL, NULL, '15.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(59, 3, 3, 'Prayer Fellowship', NULL, NULL, '16.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(60, 3, 3, 'Prayer Fellowship', NULL, NULL, '17.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(61, 3, 3, 'Prayer Fellowship', NULL, NULL, '18.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(62, 3, 3, 'Prayer Fellowship', NULL, NULL, '19.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(63, 3, 3, 'Prayer Fellowship', NULL, NULL, '20.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(64, 3, 3, 'Prayer Fellowship', NULL, NULL, '21.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(65, 3, 3, 'Prayer Fellowship', NULL, NULL, '22.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(66, 3, 3, 'Prayer Fellowship', NULL, NULL, '23.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(67, 4, 4, 'Morning Careflock', NULL, NULL, '1.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(68, 4, 4, 'Morning Careflock', NULL, NULL, '2.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(69, 4, 4, 'Morning Careflock', NULL, NULL, '3.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(70, 4, 4, 'Morning Careflock', NULL, NULL, '4.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(71, 4, 4, 'Morning Careflock', NULL, NULL, '5.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(72, 4, 4, 'Morning Careflock', NULL, NULL, '6.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(73, 4, 4, 'Morning Careflock', NULL, NULL, '7.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(74, 4, 4, 'Morning Careflock', NULL, NULL, '8.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(75, 4, 4, 'Morning Careflock', NULL, NULL, '9.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(76, 4, 4, 'Morning Careflock', NULL, NULL, '10.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(77, 4, 4, 'Morning Careflock', NULL, NULL, '11.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(78, 4, 4, 'Morning Careflock', NULL, NULL, '12.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(79, 4, 4, 'Morning Careflock', NULL, NULL, '13.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(80, 4, 4, 'Morning Careflock', NULL, NULL, '14.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(81, 4, 4, 'Morning Careflock', NULL, NULL, '15.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(82, 4, 4, 'Morning Careflock', NULL, NULL, '16.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(83, 4, 4, 'Morning Careflock', NULL, NULL, '17.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(84, 4, 4, 'Morning Careflock', NULL, NULL, '18.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(85, 4, 4, 'Morning Careflock', NULL, NULL, '19.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(86, 4, 4, 'Morning Careflock', NULL, NULL, '20.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(87, 4, 4, 'Morning Careflock', NULL, NULL, '21.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(88, 4, 4, 'Morning Careflock', NULL, NULL, '22.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(89, 4, 4, 'Morning Careflock', NULL, NULL, '23.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(90, 4, 4, 'Morning Careflock', NULL, NULL, '24.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(91, 4, 4, 'Morning Careflock', NULL, NULL, '25.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(92, 4, 4, 'Morning Careflock', NULL, NULL, '26.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(93, 4, 4, 'Morning Careflock', NULL, NULL, '27.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(94, 4, 4, 'Morning Careflock', NULL, NULL, '28.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(95, 4, 4, 'Morning Careflock', NULL, NULL, '29.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(96, 4, 4, 'Morning Careflock', NULL, NULL, '30.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(97, 4, 4, 'Morning Careflock', NULL, NULL, '31.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(98, 4, 4, 'Morning Careflock', NULL, NULL, '32.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(99, 4, 4, 'Morning Careflock', NULL, NULL, '33.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(100, 4, 4, 'Morning Careflock', NULL, NULL, '34.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(101, 4, 4, 'Morning Careflock', NULL, NULL, '35.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(102, 4, 4, 'Morning Careflock', NULL, NULL, '36.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(103, 4, 4, 'Morning Careflock', NULL, NULL, '37.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(104, 4, 4, 'Morning Careflock', NULL, NULL, '38.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(105, 4, 4, 'Morning Careflock', NULL, NULL, '39.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(106, 4, 4, 'Morning Careflock', NULL, NULL, '40.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(107, 4, 4, 'Morning Careflock', NULL, NULL, '41.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(108, 4, 4, 'Morning Careflock', NULL, NULL, '42.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(109, 4, 4, 'Morning Careflock', NULL, NULL, '43.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(110, 4, 4, 'Morning Careflock', NULL, NULL, '44.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(111, 4, 4, 'Morning Careflock', NULL, NULL, '45.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(112, 4, 4, 'Morning Careflock', NULL, NULL, '46.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(113, 4, 4, 'Morning Careflock', NULL, NULL, '47.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(114, 4, 4, 'Morning Careflock', NULL, NULL, '48.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(115, 4, 4, 'Morning Careflock', NULL, NULL, '49.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(116, 4, 4, 'Morning Careflock', NULL, NULL, '50.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(117, 4, 4, 'Morning Careflock', NULL, NULL, '51.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(118, 4, 4, 'Morning Careflock', NULL, NULL, '52.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(119, 4, 4, 'Morning Careflock', NULL, NULL, '53.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(120, 4, 4, 'Morning Careflock', NULL, NULL, '54.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(121, 4, 4, 'Morning Careflock', NULL, NULL, '55.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(122, 4, 4, 'Morning Careflock', NULL, NULL, '56.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(123, 4, 4, 'Morning Careflock', NULL, NULL, '57.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(124, 4, 4, 'Morning Careflock', NULL, NULL, '58.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(125, 4, 4, 'Morning Careflock', NULL, NULL, '59.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(126, 4, 4, 'Morning Careflock', NULL, NULL, '60.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(127, 4, 4, 'Morning Careflock', NULL, NULL, '61.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(128, 4, 4, 'Morning Careflock', NULL, NULL, '62.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(129, 4, 4, 'Morning Careflock', NULL, NULL, '63.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(130, 4, 4, 'Morning Careflock', NULL, NULL, '64.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(131, 4, 4, 'Morning Careflock', NULL, NULL, '65.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(132, 4, 4, 'Morning Careflock', NULL, NULL, '66.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(133, 4, 4, 'Morning Careflock', NULL, NULL, '67.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(134, 4, 4, 'Morning Careflock', NULL, NULL, '68.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(135, 4, 4, 'Morning Careflock', NULL, NULL, '69.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(136, 4, 4, 'Morning Careflock', NULL, NULL, '70.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(137, 4, 4, 'Morning Careflock', NULL, NULL, '71.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(138, 4, 4, 'Morning Careflock', NULL, NULL, '72.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(139, 4, 4, 'Morning Careflock', NULL, NULL, '73.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(140, 4, 4, 'Morning Careflock', NULL, NULL, '74.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(141, 4, 4, 'Morning Careflock', NULL, NULL, '75.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(142, 4, 4, 'Morning Careflock', NULL, NULL, '76.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(143, 4, 4, 'Morning Careflock', NULL, NULL, '77.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(144, 4, 4, 'Morning Careflock', NULL, NULL, '78.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(145, 4, 4, 'Morning Careflock', NULL, NULL, '79.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(146, 4, 4, 'Morning Careflock', NULL, NULL, '80.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(147, 4, 4, 'Morning Careflock', NULL, NULL, '81.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(148, 4, 4, 'Morning Careflock', NULL, NULL, '82.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(149, 4, 4, 'Morning Careflock', NULL, NULL, '83.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(150, 4, 4, 'Morning Careflock', NULL, NULL, '84.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(151, 4, 4, 'Morning Careflock', NULL, NULL, '85.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(152, 4, 4, 'Morning Careflock', NULL, NULL, '86.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(153, 4, 4, 'Morning Careflock', NULL, NULL, '87.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(154, 4, 4, 'Morning Careflock', NULL, NULL, '88.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(155, 4, 4, 'Morning Careflock', NULL, NULL, '89.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(156, 4, 4, 'Morning Careflock', NULL, NULL, '90.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(157, 4, 4, 'Morning Careflock', NULL, NULL, '91.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(158, 4, 4, 'Morning Careflock', NULL, NULL, '92.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(159, 4, 4, 'Morning Careflock', NULL, NULL, '93.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(160, 4, 4, 'Morning Careflock', NULL, NULL, '94.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(161, 4, 4, 'Morning Careflock', NULL, NULL, '95.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(162, 4, 4, 'Morning Careflock', NULL, NULL, '96.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(163, 4, 4, 'Morning Careflock', NULL, NULL, '97.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(164, 4, 4, 'Morning Careflock', NULL, NULL, '98.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(165, 4, 4, 'Morning Careflock', NULL, NULL, '99.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(166, 4, 4, 'Morning Careflock', NULL, NULL, '100.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(167, 4, 4, 'Morning Careflock', NULL, NULL, '101.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(168, 4, 4, 'Morning Careflock', NULL, NULL, '102.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(169, 4, 4, 'Morning Careflock', NULL, NULL, '103.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(170, 4, 4, 'Morning Careflock', NULL, NULL, '104.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(171, 4, 4, 'Morning Careflock', NULL, NULL, '105.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(172, 4, 4, 'Morning Careflock', NULL, NULL, '106.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(173, 4, 4, 'Morning Careflock', NULL, NULL, '107.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(174, 4, 4, 'Morning Careflock', NULL, NULL, '108.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(175, 4, 4, 'Morning Careflock', NULL, NULL, '109.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(176, 5, 5, 'Worship Commitment', NULL, NULL, '1.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(177, 5, 5, 'Worship Commitment', NULL, NULL, '2.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(178, 5, 5, 'Worship Commitment', NULL, NULL, '3.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(179, 5, 5, 'Worship Commitment', NULL, NULL, '4.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(180, 5, 5, 'Worship Commitment', NULL, NULL, '5.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(181, 5, 5, 'Worship Commitment', NULL, NULL, '6.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(182, 5, 5, 'Worship Commitment', NULL, NULL, '7.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(183, 5, 5, 'Worship Commitment', NULL, NULL, '8.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(184, 5, 5, 'Worship Commitment', NULL, NULL, '9.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(185, 5, 5, 'Worship Commitment', NULL, NULL, '10.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(186, 5, 5, 'Worship Commitment', NULL, NULL, '11.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(187, 5, 5, 'Worship Commitment', NULL, NULL, '12.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(188, 5, 5, 'Worship Commitment', NULL, NULL, '13.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(189, 5, 5, 'Worship Commitment', NULL, NULL, '14.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(190, 5, 5, 'Worship Commitment', NULL, NULL, '15.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(191, 5, 5, 'Worship Commitment', NULL, NULL, '16.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(192, 5, 5, 'Worship Commitment', NULL, NULL, '17.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(193, 5, 5, 'Worship Commitment', NULL, NULL, '18.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(194, 5, 5, 'Worship Commitment', NULL, NULL, '19.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(195, 5, 5, 'Worship Commitment', NULL, NULL, '20.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(196, 5, 5, 'Worship Commitment', NULL, NULL, '21.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(197, 5, 5, 'Worship Commitment', NULL, NULL, '22.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(198, 5, 5, 'Worship Commitment', NULL, NULL, '23.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(199, 5, 5, 'Worship Commitment', NULL, NULL, '24.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(200, 5, 5, 'Worship Commitment', NULL, NULL, '25.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(201, 5, 5, 'Worship Commitment', NULL, NULL, '26.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(202, 5, 5, 'Worship Commitment', NULL, NULL, '27.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(203, 5, 5, 'Worship Commitment', NULL, NULL, '28.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(204, 5, 5, 'Worship Commitment', NULL, NULL, '29.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(205, 5, 5, 'Worship Commitment', NULL, NULL, '30.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(206, 5, 5, 'Worship Commitment', NULL, NULL, '31.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(207, 5, 5, 'Worship Commitment', NULL, NULL, '32.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(208, 5, 5, 'Worship Commitment', NULL, NULL, '33.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(209, 5, 5, 'Worship Commitment', NULL, NULL, '34.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(210, 5, 5, 'Worship Commitment', NULL, NULL, '35.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(211, 5, 5, 'Worship Commitment', NULL, NULL, '36.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(212, 5, 5, 'Worship Commitment', NULL, NULL, '37.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(213, 5, 5, 'Worship Commitment', NULL, NULL, '38.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(214, 5, 5, 'Worship Commitment', NULL, NULL, '39.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(215, 5, 5, 'Worship Commitment', NULL, NULL, '40.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(216, 5, 5, 'Worship Commitment', NULL, NULL, '41.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(217, 5, 5, 'Worship Commitment', NULL, NULL, '42.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(218, 5, 5, 'Worship Commitment', NULL, NULL, '43.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(219, 5, 5, 'Worship Commitment', NULL, NULL, '44.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(220, 5, 5, 'Worship Commitment', NULL, NULL, '45.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(221, 5, 5, 'Worship Commitment', NULL, NULL, '46.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(222, 5, 5, 'Worship Commitment', NULL, NULL, '47.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(223, 5, 5, 'Worship Commitment', NULL, NULL, '48.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(224, 5, 5, 'Worship Commitment', NULL, NULL, '49.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(225, 5, 5, 'Worship Commitment', NULL, NULL, '50.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(226, 5, 5, 'Worship Commitment', NULL, NULL, '51.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(227, 5, 5, 'Worship Commitment', NULL, NULL, '52.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(228, 5, 5, 'Worship Commitment', NULL, NULL, '53.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(229, 5, 5, 'Worship Commitment', NULL, NULL, '54.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(230, 5, 5, 'Worship Commitment', NULL, NULL, '55.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(231, 5, 5, 'Worship Commitment', NULL, NULL, '56.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(232, 5, 5, 'Worship Commitment', NULL, NULL, '57.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(233, 5, 5, 'Worship Commitment', NULL, NULL, '58.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(234, 5, 5, 'Worship Commitment', NULL, NULL, '59.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(235, 5, 5, 'Worship Commitment', NULL, NULL, '60.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(236, 5, 5, 'Worship Commitment', NULL, NULL, '61.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(237, 5, 5, 'Worship Commitment', NULL, NULL, '62.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(238, 5, 5, 'Worship Commitment', NULL, NULL, '63.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(239, 5, 5, 'Worship Commitment', NULL, NULL, '64.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(240, 5, 5, 'Worship Commitment', NULL, NULL, '65.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(241, 5, 5, 'Worship Commitment', NULL, NULL, '66.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(242, 5, 5, 'Worship Commitment', NULL, NULL, '67.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(243, 5, 5, 'Worship Commitment', NULL, NULL, '68.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(244, 5, 5, 'Worship Commitment', NULL, NULL, '69.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(245, 5, 5, 'Worship Commitment', NULL, NULL, '70.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(246, 5, 5, 'Worship Commitment', NULL, NULL, '71.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(247, 5, 5, 'Worship Commitment', NULL, NULL, '72.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(248, 5, 5, 'Worship Commitment', NULL, NULL, '73.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(249, 5, 5, 'Worship Commitment', NULL, NULL, '74.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(250, 5, 5, 'Worship Commitment', NULL, NULL, '75.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(251, 5, 5, 'Worship Commitment', NULL, NULL, '76.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(252, 5, 5, 'Worship Commitment', NULL, NULL, '77.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(253, 5, 5, 'Worship Commitment', NULL, NULL, '78.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(254, 5, 5, 'Worship Commitment', NULL, NULL, '79.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');
INSERT INTO `photos` VALUES(255, 5, 5, 'Worship Commitment', NULL, NULL, '80.jpg', '0000-00-00 00:00:00', '2014-07-29 14:43:48');

-- --------------------------------------------------------

--
-- Table structure for table `praisewall_amens`
--

CREATE TABLE `praisewall_amens` (
  `sns_id` int(11) NOT NULL,
  `praisewall_id` varchar(128) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `status` enum('AMENED','UNAMENED') DEFAULT 'UNAMENED',
  `last_updated` datetime NOT NULL,
  UNIQUE KEY `profile_id` (`sns_id`,`praisewall_id`),
  KEY `praisewall_id` (`praisewall_id`),
  KEY `last_updated` (`last_updated`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `praisewall_amens`
--

INSERT INTO `praisewall_amens` VALUES(2147483647, '13', 'Jchikkadummy Jchikkadummy', 'http://graph.facebook.com/jchikkadummy.jchikkadummy/picture?width=30', 'AMENED', '0000-00-00 00:00:00');
INSERT INTO `praisewall_amens` VALUES(2147483647, '12', 'Jchikkadummy Jchikkadummy', 'http://graph.facebook.com/jchikkadummy.jchikkadummy/picture?width=30', 'AMENED', '0000-00-00 00:00:00');
INSERT INTO `praisewall_amens` VALUES(2147483647, '11', 'Jhesed Tacadena', 'http://graph.facebook.com/jhesed.tacadena/picture?width=30', 'AMENED', '0000-00-00 00:00:00');
INSERT INTO `praisewall_amens` VALUES(2147483647, '14', 'Jhesed Tacadena', 'http://graph.facebook.com/jhesed.tacadena/picture?width=30', 'AMENED', '0000-00-00 00:00:00');
INSERT INTO `praisewall_amens` VALUES(0, '', '', '', 'AMENED', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `praise_wall`
--

CREATE TABLE `praise_wall` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `sns_type` varchar(10) DEFAULT NULL,
  `author_sns_id` int(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `wall_title` text,
  `message` text,
  `picture` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amen_count` int(10) DEFAULT '0',
  `user_amen_ids` text,
  `like_count` int(10) DEFAULT '0',
  `user_like_ids` text,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `praise_wall`
--

INSERT INTO `praise_wall` VALUES(1, 'FB', 2147483647, 'Jhesed Tacadena', 'Thank You Lord', 'Lord, I thank You for this website. \r\n	Please be glorified in us Lord.  Amen.', 'http://graph.facebook.com/jhesed.tacadena/picture?height=90&width=90', NULL, NULL, NULL, 0, NULL, 0, NULL, '2014-07-29 14:44:01', '2014-07-29 14:44:01');

-- --------------------------------------------------------

--
-- Table structure for table `prayerwall_amens`
--

CREATE TABLE `prayerwall_amens` (
  `sns_id` int(11) NOT NULL,
  `prayerwall_id` varchar(128) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `status` enum('AMENED','UNAMENED') DEFAULT 'UNAMENED',
  `last_updated` datetime NOT NULL,
  UNIQUE KEY `profile_id` (`sns_id`,`prayerwall_id`),
  KEY `prayerwall_id` (`prayerwall_id`),
  KEY `last_updated` (`last_updated`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prayerwall_amens`
--


-- --------------------------------------------------------

--
-- Table structure for table `prayer_wall`
--

CREATE TABLE `prayer_wall` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `sns_type` varchar(10) DEFAULT NULL,
  `author_sns_id` int(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `wall_title` text,
  `message` text,
  `picture` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amen_count` int(10) DEFAULT '0',
  `user_amen_ids` text,
  `like_count` int(10) DEFAULT '0',
  `user_like_ids` text,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `prayer_wall`
--

INSERT INTO `prayer_wall` VALUES(1, 'FB', 2147483647, 'Jhesed Tacadena', 'Thank You Lord', 'Lord, I thank You for this website. \r\n	Please be glorified in us Lord.  Amen.', 'http://graph.facebook.com/jhesed.tacadena/picture?height=90&width=90', NULL, NULL, NULL, 0, NULL, 0, NULL, '0000-00-00 00:00:00', '2014-08-30 20:44:55');

-- --------------------------------------------------------

--
-- Table structure for table `sns_facebook`
--

CREATE TABLE `sns_facebook` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `access_token` text,
  `expiration` int(15) DEFAULT '0',
  `sns_id` int(50) NOT NULL,
  `email` varchar(32) DEFAULT NULL,
  `first_name` varchar(32) DEFAULT NULL,
  `last_name` varchar(32) DEFAULT NULL,
  `profile_url` varchar(100) DEFAULT NULL,
  `displayname` varchar(64) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `hometown` varchar(64) DEFAULT NULL,
  `pic_square` varchar(100) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sns_facebook`
--

INSERT INTO `sns_facebook` VALUES(1, 'CAAHkQwNZAJDUBAILDeyoPWftr9sGpBp55e06a0zykmeTvu3RQQJdSirQoE5kzbUAtrf7t7sybZBqWsiHLaL3loBE5lPuZBsA8rkb8tBjz6lDzNQzNJ09arFqMPoOorPZCPclzZAokijp9ZBgo1yyQnWs4XaNZAZAGZCuErl2XZABocmlpE8g61e005ZA84oj1Q7pbrZCL7MWATtbrVIX8HimnQYI', 0, 2147483647, 'jhesed_astigsilord@yahoo.com', 'Jhesed', 'Tacadena', 'https://www.facebook.com/jhesed.tacadena', 'Jhesed Tacadena', 'jhesed.tacadena', 'male', 'Bilibiran, Rizal, Philippines', NULL, '0000-00-00 00:00:00', '2014-05-13 07:35:15');
INSERT INTO `sns_facebook` VALUES(2, 'CAAHkQwNZAJDUBAFV0QQZClwQ8OSjDMPnEyyn7VfUwVZAdrZA46wXF53l8xP2PETpdrZCXQP76ZAHjaPKL9or5rCqEKrZBT2C734xKytwm3Tpl3JM7Gb5b3DjafE6P9e0GEXphdggMiXMXjbbb0b73urUFPUHziipHKcAOrRJBTYM1xUP9JiXOEeui3ZCnZAFlHK3rlDcQI0BjnviFP9VXtZAFP', 0, 2147483647, 'jhesednewdummy@gmail.com', 'Jchikkadummy', 'Jchikkadummy', 'https://www.facebook.com/jchikkadummy.jchikkadummy', 'Jchikkadummy Jchikkadummy', 'jchikkadummy.jchikkadummy', 'male', '', NULL, '0000-00-00 00:00:00', '2014-05-29 20:39:03');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `video_presentation` varchar(50) DEFAULT NULL,
  `network` varchar(15) DEFAULT NULL,
  `youtube_code` text,
  `featured` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` VALUES(1, 'RiBAF 2012 - Promotional Video 1', 'RiBAF', 'Jehannah Tacadena', NULL, 'MzJ9WuYGRuQ', 0);
INSERT INTO `videos` VALUES(2, 'RiBAF 2012 - Promotional Video 2', 'RiBAF', 'Jehannah Tacadena', NULL, 'WKJcyXq_uJg', 0);
INSERT INTO `videos` VALUES(3, 'Lenten JAF 2012', 'JAF', 'Jehannah Tacadena', NULL, 'mBQKvSgyruc', 0);
INSERT INTO `videos` VALUES(4, 'Lenten JAF 2013', 'JAF', 'Jehannah Tacadena', 'PTV4: Lakbayin ', 'Tp8zM38zOqk', 0);

-- --------------------------------------------------------

--
-- Table structure for table `weekly_bulletin`
--

CREATE TABLE `weekly_bulletin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `week` date DEFAULT NULL,
  `header_title` varchar(100) DEFAULT NULL,
  `day_in_int` varchar(3) DEFAULT NULL,
  `series_title` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(30) DEFAULT 'Jose Tacadena',
  `filename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `weekly_bulletin`
--

INSERT INTO `weekly_bulletin` VALUES(1, NULL, 'June 2014', '8', 'Komprehensibong Balik-aral sa Hamon ng C8, 2', NULL, 'Jose Tacadena', '2014-06-08.pdf');
INSERT INTO `weekly_bulletin` VALUES(2, NULL, 'May 2014', '11', 'Mga Babala sa Huling Panahon, 4', NULL, 'Jose Tacadena', '2014-05-11.pdf');
INSERT INTO `weekly_bulletin` VALUES(3, NULL, 'January 2015', '4', 'Si Jesus: Ang Perfect Steward ng Dios Ama, 3', NULL, 'Jose Tacadena', '01-04-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(4, NULL, 'January 2015', '11', 'Ang Mga Pinakasikat na Bible Verses sa Buong Mundo Nitong 2015', NULL, 'Jose Tacadena', '01-11-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(5, NULL, 'January 2015', '18', 'Ang Mga Pinakasikat na Bible Verses sa Buong Mundo Nitong 2015, 2', NULL, 'Jose Tacadena', '01-18-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(6, NULL, 'January 2015', '25', 'Ang Mga Pinakasikat na Bible Verses sa Buong Mundo Nitong 2015, 3', NULL, 'Jose Tacadena', '01-25-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(7, NULL, 'February 2015', '1', 'Ang Mga Pinakasikat na Bible Verses sa Buong Mundo Nitong 2015, 4', NULL, 'Jose Tacadena', '02-01-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(8, NULL, 'February 2015', '8', 'Tenang Magbulay at Magsaulo ng mga Salita ng Diyos, 1', NULL, 'Jose Tacadena', '02-08-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(9, NULL, 'February 2015', '15', 'Tenang Magbulay at Magsaulo ng mga Salita ng Diyos, 2', NULL, 'Jose Tacadena', '02-15-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(10, NULL, 'February 2015', '22', 'Tenang Magbulay at Magsaulo ng mga Salita ng Diyos, 3', NULL, 'Jose Tacadena', '02-22-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(11, NULL, 'March 2015', '1', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 1', NULL, 'Jose Tacadena', '03-01-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(12, NULL, 'March 2015', '8', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 2', NULL, 'Jose Tacadena', '03-08-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(13, NULL, 'March 2015', '15', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 3', NULL, 'Jose Tacadena', '03-15-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(14, NULL, 'March 2015', '22', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 4', NULL, 'Jose Tacadena', '03-22-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(15, NULL, 'March 2015', '29', 'From Prayer Walk to Praise Walk!', NULL, 'Jose Tacadena', '03-29-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(16, NULL, 'April 2015', '5', 'Sa Pagbabalik ni Hesus', NULL, 'Jose Tacadena', '04-05-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(17, NULL, 'April 2015', '12', 'Kapamilya Ko, Kapuso Ko Kay Kristo, 1', NULL, 'Jose Tacadena', '04-12-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(18, NULL, 'April 2015', '19', 'Kapamilya Ko, Kapuso Ko Kay Kristo, 2', NULL, 'Jose Tacadena', '04-19-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(19, NULL, 'April 2015', '26', 'Kapamilya Ko, Kapuso Ko Kay Kristo, 3', NULL, 'Jose Tacadena', '04-26-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(20, NULL, 'May 2015', '3', 'Pagbungkal ng mga Aral sa Aklat ng Mangangaral', NULL, 'Jose Tacadena', '05-03-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(21, NULL, 'May 2015', '10', 'Walang Kabuluhan ang Buhay na Di Nakatuon sa Dios', NULL, 'Jose Tacadena', '05-10-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(22, NULL, 'May 2015', '17', 'Walang Kabuluhan ang Buhay na Di Nakatuon sa Dios, 2', NULL, 'Jose Tacadena', '05-17-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(23, NULL, 'May 2015', '24', 'Walang Kabuluhan ang Buhay na Di Nakatuon sa Dios, 3', NULL, 'Jose Tacadena', '05-24-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(24, NULL, 'May 2015', '31', 'Ang Tunay na Makabuluhang Buhay', NULL, 'Jose Tacadena', '05-31-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(25, NULL, 'June 2015', '7', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 5', NULL, 'Jose Tacadena', '06-07-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(26, NULL, 'June 2015', '14', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 6', NULL, 'Jose Tacadena', '06-14-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(27, NULL, 'June 2015', '21', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 7', NULL, 'Jose Tacadena', '06-21-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(28, NULL, 'June 2015', '28', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 8', NULL, 'Jose Tacadena', '06-28-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(29, NULL, 'July 2015', '5', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 9', NULL, 'Jose Tacadena', '07-05-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(30, NULL, 'July 2015', '12', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 10', NULL, 'Jose Tacadena', '07-12-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(31, NULL, 'July 2015', '19', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 11', NULL, 'Jose Tacadena', '07-19-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(32, NULL, 'July 2015', '26', 'Walong Pananagutan at Pribilehiyo Tungo sa Malawak at Balanseng Buhay-Cristiano, 12', NULL, 'Jose Tacadena', '07-26-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(33, NULL, 'August 2015', '2', 'The Lord Jesus Christ: the Perfect Example of Self-Discplined Life', NULL, 'Jose Tacadena', '08-02-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(34, NULL, 'August 2015', '9', 'Kailangan na Talagang Maging Self-Discplined!', NULL, 'Jose Tacadena', '08-09-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(35, NULL, 'August 2015', '16', 'Kailangan na Talagang Maging Self-Discplined!, 2', NULL, 'Jose Tacadena', '08-16-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(36, NULL, 'August 2015', '23', 'Kailangan na Talagang Maging Self-Discplined!, 3', NULL, 'Jose Tacadena', '08-23-2015.pdf');
INSERT INTO `weekly_bulletin` VALUES(37, NULL, 'August 2015', '30', 'Ang Self-Disciplined Life: Angkop na Papuri sa Dios!', NULL, 'Jose Tacadena', '08-30-2015.pdf');
