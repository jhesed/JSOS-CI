-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 21, 2016 at 11:39 AM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a3176676_pmm`
--

-- --------------------------------------------------------

--
-- Table structure for table `ria_buddies`
--

CREATE TABLE `ria_buddies` (
  `b_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `m_id` int(10) DEFAULT NULL,
  `fname` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `lname` varchar(25) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`b_id`),
  KEY `m_id` (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ria_buddies`
--

INSERT INTO `ria_buddies` VALUES(1, NULL, 'Jhesed', 'Tacadena');
INSERT INTO `ria_buddies` VALUES(2, NULL, 'Hannah', 'Tanlangco');
INSERT INTO `ria_buddies` VALUES(3, NULL, 'riazel', 'evasco');
INSERT INTO `ria_buddies` VALUES(4, NULL, 'Zoren', 'Roque');
INSERT INTO `ria_buddies` VALUES(5, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ria_members`
--

CREATE TABLE `ria_members` (
  `m_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fname` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `lname` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `birthdate` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `cellphone` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ria_members`
--

INSERT INTO `ria_members` VALUES(1, '', '', '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `salvation`
--

CREATE TABLE `salvation` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `author` varchar(100) DEFAULT NULL,
  `content` text,
  `year_born_again` int(5) DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `language_written` varchar(30) DEFAULT 'Filipino',
  `dp` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `salvation`
--

INSERT INTO `salvation` VALUES(1, 'Ang Aking Patotoo', 'Ronald Bolesa JR.', '        <p> Ang buhay ko ay maikukumpara ko sa isang paglalakbay, literal at simbolikal. Bata pa lang ako palipat-lipat na kami ng pamilya ko ng tirahan. Pinanganak ng Cebu City, nalipat ng Tondo, Apalit, Angono, Naga City, Legazpi City, Cardona at Taytay. Sadyang walang permanente sa mundo, lahat ay nagbabago. </p>\r\n\r\n        <p>Napakaraming mga masasama at masasakit na alaala mula pa lang pagkabata. Ilan sa mga ito ay di pa rin magawang malimutan dahil sa  napakasalimuot na mga nasaksihan at naranasan.</p>\r\n\r\n        <p>Masasabi kong naging isang  mabait na bata naman ako. Ngunit kung paanong nagbabago ang aking pisikal na kaanyuan,at ang mundo,  gayon din naman ang pagbabago na nagaganap sa aking pagkatao. Pagtuntong ko ng high school ay nag-iba ang aking mga gawi at ugali. Naging palamura ako, at isang tila satanistang rakista (rock & roll), atbp.</p>\r\n\r\n        <p>Ibang-iba na nga ako. Di man kita ng iba, ayaw ko ng ganoong pagkatao. Noong bata pa ako lagi akong nagsa-sign of the cross. Sinisikap kong mahanap ang Diyos,gawin ang gusto Niya, maging mabait, baguhin ang sarili pero sadyang napakalakas ng hatak ng kamunduhan na tila wala ng puwang ang Krus sa puso ko. Paboritong linya ko ng rap ang “gusto kong bumait pero di ko magawa…nasa Diyos ang awa nasa tao ang gawa .“ Di ko pansin, isa na palang dasal ng puso kong gusto nang magbago ang awit na iyon.</p>\r\n	\r\n        <p>Hindi ko alam na isang mas madilim na daan pa pala ang tatahakin ng aking paglalakbay. Kinse anyos ako ng isang pangyayari ang naganap: Agosto 22, 2000, Martes ng gabi, matutulog na sana kami, na-high blood ang papa ko. Na-comatose siya, at lumipas ang dalawang araw, tuluyan na siyang binawian ng buhay. Hinding-hindi ko malilimutan kung paano siya lumuha habang tinatakbo siya sa ospital: kung paano siya nag-aagaw-buhay sa I.C.U. Hinding-hindi ko siya malilimutan.</p>\r\n\r\n        <p>Lumipas ang mga araw, pagkatapos ng libing, sinikap naming maging normal ang buhay, pero napakahirap. Sa tuwing may dadaan na tricycle o titigil sa tapat ng bahay namin, tatayo kami at pupunta kami sa pintuan upang salubungin ang papa naming gaya ng nakasanayan namin, umaasa pa rin na sa pagbukas ng pinto ay si papa ang bubungad, pero ang katotohanan ay hanggang panaginip na lamang iyon. Dito na ako tuluyang naligaw. Sinubukan ang pag-inom ng alak, paninigarilyo, marijuana at maling relasyon. Napakahirap kumawala. Ayaw ko namang gawin ang mga iyon, pero ginagawa ko pa rin. Gusto ko nang magbago.</p>\r\n        \r\n        <p>Kaya pinangarap kong magkaroon ng barkadang walang bisyo. Di naglaon ay nakilala ko sila Dagul, Ojen atbp. Naging solid ang tropa na iisa ang bisyo   basketball. Sa tulong nila, nalayo ako sa masamang barkada. Minsan, kinausap kami ni Mark Go, sali raw kami sa paliga. Dahil libre, at adik nga kami dito, oo agad kami. Medyo pinalad kami, champion eh, iba talaga pag nagkakaamuyan na.</p>\r\n\r\n        <p>Pagkatapos ng liga, naging regular ang pagbisita ng team ni Ptr. Joe. Hinding-hindi ko malilimutan ang minsang naging deklarsyon ko pag-alis nila pastor (ang kukulit kasi eh): “hinding-hindi ako magiging born again.”</p>\r\n\r\n        <p>June 02, 2002, inimbitahan kami para sa awarding. Siyempre,kahit alam naming sa church ang lugar ng pagdadausan, pumunta kami, di kami pwede mawala doon. Lingid sa aming kaalaman, may plano pala ang Diyos sa amin ng araw na iyon. Nagbigay ng mensahe si Ptr. Joe at sa dulo nito, isang imbitasyon ng pagtanggap kay Jesus. Ayaw ko, kasi nakakahiya sa harap ng tropa, pero gusto ko rin, dahil matagal ko na Siyang hinahanap. Pero sa kadulo-duluhan, isa ako sa mga huling tumayo at lumapit sa altar upang tanggapin si Jesus bilang Panginoon ko at Tagapagligtas. Nanaig ang pagkauhaw ng aking kaluluwa. Bahala na kung ano ang iisipin ng mga barkada ko.</p>\r\n\r\n        <p>Naging regular na ang aking pag-atend ng J.S.O.S., pero dumating din ang punto na ako ay nanlamig at tuluyan na ngang nawala. Nagdesisyon na ako na wag nang magsimba. Maging sa mga outreach Bible studies ay di na rin ako sumasama.</p>\r\n\r\n        <p>Pero di nagsawa ang Diyos sa akin. Kinausap ako ni Dagul na bubuo ng basketball team ang JSOS, at ang makakasali lang sa line-up ay ang mga nagsisimba. Kaya sa motibasyon ng basketball, bumalik ako para makasali. Pero di ko inaasahan na yun na pala simula ng aking magiging lubusang pagsuko sa Diyos. Sa simbahan,habang nagbibigay ng mensahe ang pastor, isang pambihirang pagkilos ang ginawa ng Diyos. Sobrang nahaplos ang aking puso sa mensahe at unang beses kong naramdam ang Diyos. Umiiyak ako at sinabi ko sa Kanya, “di na ako magsisimba dahil sa basketball, kundi dahil sa Iyo.”</p>\r\n\r\n        <p>Napakarami pang nangyari sa buhay ko. Palipat-lipat ng lugar dahil sa sobrang kahirapan, at walang makain, grabe, gutom talaga. Minsan na akong namuhay ng mag-isa, salamat sa Bibliang (Bagong Tipan) bigay ni Kuya Chris, sa tulong nito natuto akong manalangin. Pagkalipas ng mahigit kumulang 3 buwan, napunta naman kami ng Cardona, kung saan pinakagrabe ang kahirapan, pero sa tulong ng Biblia (Lumang Tipan), naging matatag ako dahil sa inspirasyon ng mga kwento ng buhay ng tao sa Biblia.</p>\r\n\r\n        <p>Napakarami pang mga pagsubok ang aking hinarap, hinding-hindi ko malilimutan na minsang nasabi ko sa Kanya na “wala Kang kwentang Diyos”, dahil suko na ako. Pero di Siya nagbago, inibig Niya pa rin ako at inabot mula sa kadiliman. </p>\r\n\r\n        <p>Tunay na hindi maiiwasan ang mga pagsubok sa buhay, pero hindi na ako susukong muli dahil subok ko na ang pagmamahal ng Diyos sa akin na naging Ama ko sa aking pangungulila. Patuloy na magtitiwala at ipagkatitiwala ang aking buhay kay Jesus. Panghahawakan ko angKanyang pangakong magandang plano sa aking buhay, isang buhay na masagana at punong-puno ng pag-asa. Salamat Panginoon sa tiyak na kinabukasan (Jer. 29:11).Hindi man permanente at nagbabago ang mundo, iisa ang alam kong hinding-hindi magbabago, ang pag-ibig ng ating Diyos Ama sa atin.</p>\r\n\r\n        ', 2002, 'Sportfest', 'Filipino', 'ronaldbolesa.PNG');
INSERT INTO `salvation` VALUES(2, 'Unti-unting Pagbabago', 'Raymark Sultan', '        <h2>Buhay ko noon</h2>\r\n        <p>Bagamat namulat sa Children’s Sunday School, lumaki akong isang tambay -- naninigarilyo, umiinom ng alak kung minsan, at mahilig sa away.  Sumasama rin ako sa fraternity at madalas makasaksi ng mga bugbugan.  Hilig ko rin na mambato ng bubong ng ibang mga bahay.  Kahit na hindi ako nakatikim, naranasan ko rin na makasilamuha sa mga humihithit ng marijuana.</p>\r\n\r\n        <h2>Paano ko nakilala ang Panginoon</h2>\r\n        <p>Ngunit dumating ang isang Linggo ng Sunday School na may pinaliwanag si tita Rose na nagpabago sa aking buhay.  Gumamit siya ng isang maliit na booklet kung tawagin nila ay “Ang Sagot”.  Doon ipinaliwanag ang kasalanan ng tao.  At ayokong mapunta sa impyerno.  Natakot ako.  Kaya nagpasya akong tanggapin si Hesus sa puso ko.</p>\r\n\r\n        <h2>Buhay ko ngayon</h2>\r\n        <p>Kahit na hindi biglaan, mayroong pagbabago.  Ngayong 16 years old na ako, natuto akong sumama sa mga Bible Study.  Ang dating tinuturuan ay nagtuturo na rin sa mga follow-up sessions.  Nagpapatanggap na sa Panginoon ang dating pinatanggap.  At natututo na ring tumugtog ng drums para sa Panginoon.</p>\r\n        ', 0, 'Sunday School', 'Filipino', 'raymarksultan.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `vocalist` varchar(100) DEFAULT NULL,
  `composer` varchar(50) DEFAULT NULL,
  `genre` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `arranger` varchar(50) DEFAULT NULL,
  `instrumentalists` text,
  `video_presentation` varchar(50) DEFAULT NULL,
  `youtube_code` text,
  `lyrics` text,
  `featured` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` VALUES(1, 'Ititik Mo', 'Ronald Bolesa, Aileen Blanca, Romeo Alkuino, Zisa Blanca, Lovely Lucero', 'Jose Tacadena', 'Digital', 'Theme song: Bible Art Parade', 'Jhesed Tacadena', NULL, 'Hannah Tanlangco', 'OhaSnhcLC-E', 'Pinagpala Mo ang sangkatauhan <br/>\r\n    Ng Iyong ipasulat ang Iyong Salita <br/>\r\n    Kinasihan Mo mga pili Mong tauhan <br/>\r\n    Sa pagsulat ng kamangha-mangha Mong Diwa <br/><br/>\r\n    \r\n    Ngayon nga ang Salita Mo''y nababasa na <br/>\r\n    Bawat titik ay may himalang halina <br/>\r\n    Nagbabago ng puso, nagpapanday ng buhay <br/>\r\n    Sa tamang landasin tunay na gabay <br/><br/>\r\n    \r\n    Ititik Mo po Salita Mo sa puso namin <br/>\r\n    Aklat Mo sa puso nami''y sisipiin <br/>\r\n    Sa gayon ngalan Mo''y tatatak sa aming gawain <br/>\r\n    Mga buhay na liham Mo kami''y tatawagin <br/>\r\n    ', 0);
INSERT INTO `songs` VALUES(2, 'Sa''Yo Ako''y Mag-aalay', 'Aileen Blanca, Zisa Blanca', 'Jose Tacadena', 'Solemn', 'Offering Song', NULL, 'Keyboard: Ronald Bolesa', 'Hannah Tanlangco', 'joLvJ4NyKKc', 'Sa''Yo ako''y mag-aalay <br/>\r\n    PPagpapalang ''Yong binigay <br/>\r\n    Lahat nama''y pag-aari Mo <br/>\r\n    Katiwala lamang ako <br/><br/>\r\n    \r\n    Ikaw ang Diyos na mapagbigay <br/>\r\n    Sinakripisyo Mo ang Iyong buhay <br/>\r\n    Kaya naman ako rin ay mag-aalay <br/>\r\n    Munting handog sa''Yong kamay <br/><br/>\r\n    \r\n    Lahat ng tinatamasa <br/> \r\n    Sa''Yong biyaya nagmula <br/>\r\n    Oras, lakas, yama''t talino <br/>\r\n    Katiwala lamang ako <br/>', 0);
INSERT INTO `songs` VALUES(3, 'RIP (Rest in Praise)', 'Jhesed Tacadena, Aileen Blanca', 'Jhesed Tacadena', 'Digital', 'Theme song: November 2011 PraiseFest', NULL, NULL, 'Hannah Tanlangco', '2_MhtAlmzpY', '\r\n    I. <br/>\r\n    Napapagod ka na ba? <br/>\r\n    Sa iyong pagtakbo <br/>\r\n    Hinihingal ka na ba? <br/>\r\n    Sundalo ni Kristo <br/><br/>\r\n\r\n    II. <br/>\r\n    Nadarama mo ba? <br/>\r\n    Ang hapdi ng mga sugat <br/>\r\n    Na nakagugulat, ''di masukat <br/>\r\n    Kahit ika''y tapat <br/><br/>\r\n\r\n    III. <br/>\r\n    Tubig ng presensya Niya <br/>\r\n    Ang ''yong kailangan <br/>\r\n    Inumin mo na''t damhin <br/>\r\n    Ang Kanyang kalakasan <br/><br/>\r\n\r\n    IV. <br/>\r\n    ''Pagkat papuri <br/>\r\n    Ang ''yong panlaban <br/>\r\n    Sa lahat ng pagod <br/>\r\n    Na ''yong nararanasan <br/><br/>\r\n\r\n    KORO: <br/>\r\n    RIP! Rest in Praise! <br/>\r\n    Habang sumasamba, ika''y mamamangha <br/>\r\n    RIP! Rest in Praise! <br/>\r\n    At bawat pagod mo ay mawawala <br/><br/>\r\n\r\n    V. <br/>\r\n    ''Pagkat ang papuri <br/>\r\n    Ay nagbubunga <br/>\r\n    Ng lakas, <br/>\r\n    At kakaibang saya <br/> <br/>\r\n\r\n    VI. <br/>\r\n    Tititigil ang mundo <br/>\r\n    Habang sumasamba <br/>\r\n    Kaluwalhatian ng Diyos<br/>\r\n    Ay makikita nila<br/>\r\n    ', 0);
INSERT INTO `songs` VALUES(4, 'Storms will Cease', 'Jehannah Tacadena, Aileen Blanca, Zisa Blanca', 'Jose Tacadena', 'Solemn', 'Calamity', NULL, '(Guitar) Jhesed Tacadena', 'Jehannah Tacadena', 'awlsD5HvEaA', '\r\n	All storms will be ceasing <br/>\r\n	The sun will be shining <br/>\r\n	Trials and problems will be gone <br/>\r\n	The journey''s peaceful in God''s Son <br/><br/>\r\n	\r\n	All floods will be dissipating <br/>\r\n	The grounds will be appearing <br/>\r\n	Life''s trials will be overcome <br/>\r\n	God''s grace for us is just awesome <br/><br/>\r\n	\r\n	When travelling with Jesus <br/>\r\n	Salvation is enormous <br/>\r\n	He''s our Rock and Redeemer <br/>\r\n	He''s trustworthy forever <br/>	\r\n    ', 1);
INSERT INTO `songs` VALUES(5, 'Matatapos ang Bagyo', 'Jehannah Tacadena', 'Jose Tacadena', 'Solemn', 'Calamity', NULL, '(Guitar) Jhesed Tacadena', 'Jehannah Tacadena', 'MazfZ1R6AAk', '\r\n	Matatapos ang bagyo <br/>\r\n	Araw ay magliliwanag <br/>\r\n	Problema''y maglalaho <br/>\r\n	Papanatag ang paglalayag <br/><br/>\r\n	\r\n	Mawawala rin ang baha <br/>\r\n	Makikita muli ang lupa <br/>\r\n	Pagsubok tatalunin <br/>\r\n	Biyaya Niya ay kakamtin <br/><br/>\r\n	\r\n	''Pag kasama ay si Kristo <br/>\r\n	Ligtas ang buhay mo <br/>\r\n	Siya ang moog at sandigan <br/>\r\n	Maasahan kailanman <br/>	\r\n    ', 0);
